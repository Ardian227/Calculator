package Calculator;

import Calculator.KalAksi;
import java.util.List;
import java.util.ArrayList;
import java.text.DecimalFormat;

public class kalOperator {
	private List list;
	private List list2;
	private String hasil;
	private KalAksi x = new KalAksi();
	private DecimalFormat fm = new DecimalFormat("###,###.###");
	private double c;

	public List getList(){
		return list;
	}
	public void setList(List list){
		this.list = list;
	}
	public List getList2(){
		return list2;
	}
	public void setList2(List list){
		this.list = list2;
	}

	public void ambilAngkaPertama(String s){
		list = new ArrayList();
		list.add(s);
	}
	public void ambilAngkaKedua(String s){
		list2 = new ArrayList();
		list2.add(s);
	}

	public void pindahAngka(){
		list.remove(0);
		list.add(getHasil1());
	}


	public void hapusList(){
		list.remove(0);
		x.setB2(true);
	}
	public void hapusList2(){
		list.remove(0);
		x.setB2(true);
	}

	public void setActionTambah(String s){
			String as = list.get(0).toString();
			String bs = list2.get(0).toString();
			double a = Double.valueOf(as);
			double b = Double.valueOf(bs);
			String cs;
		switch (s){
			case "tambah":
				{
					c=a+b;
					cs=String.valueOf(fm.format(c));
					setHasil(cs);
					break;
				}
			case "kurang":
				{
					c=a-b;
					cs=String.valueOf(fm.format(c));
					setHasil(cs);
					break;
				}
			case "kali":
				{
					c=a*b;
					cs=String.valueOf(fm.format(c));
					setHasil(cs);
					break;
				}
			case "bagi":
				{
					c=a/b;
					cs=String.valueOf(fm.format(c));
					setHasil(cs);
					break;
				}
		}
	}
	public String getHasil1(){
		return hasil;
	}
	public void setHasil(String hasil){
		this.hasil=hasil;
	}
}