public class KalAksi{
	private String txtText="0";
	private boolean b=true;
	private boolean b2=true;
	private String tdop;

	public String getTdop(){
		return tdop;
	}
	public String setTdop(String tdop){
		this.tdop=tdop;
	}
	public boolean isB2(){
		return b2;
	}
	public void setB2(boolean b2){
		this.b2=b2;
	}
	public boolean isB(){
		return b;
	}
	public void setB(boolean b){
		this.b=b;
	}
	public void setAngka(String a){
		txtText=a;
	}
	public String getAngka(){
		return txtText;
	}
}