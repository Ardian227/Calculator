import Calculator.KalAksi;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.Font;
import org.netbeans.lib.awtextra.*;

public class KalForm implements ActionListener{
	//selanjutnya akan dilanjutkan oleh mbak fangky
	//karena saya sekarang lagi tumbang pusing kepala :'(
	//ytnya menit ke 4.26
}