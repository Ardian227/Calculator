public interface State {
 
    public boolean isStartState();
 
    public boolean isFinalState();
 
    public State validateChar(Character c) throws Exception;
}