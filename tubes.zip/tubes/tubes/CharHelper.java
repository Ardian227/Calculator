import java.util.List;

/**
 *
 * @author echo
 */
public interface CharHelper {

    public List acceptedCharacters();

    public State getState();
}