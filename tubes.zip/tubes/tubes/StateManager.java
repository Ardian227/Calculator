import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class StateManager {

    private State state;
    private String[] string;

    public StateManager(State state) {
        this.state = state;
    }

    public Integer calculate(String input) throws Exception {
        char[] chars = input.toCharArray();

        for (char c : chars) {
            // cek input
            state = state.validateChar(c);
        }

        // cek apakah state akhir merupakan final state
        if (!state.isFinalState()) {
            // jika tidak berarti error
            throw new Exception();
        }

        return calculateValidString(input);
    }

    protected Integer calculateValidString(String input) {
        StringTokenizer tokenizer = new StringTokenizer(input, "+");
        List strings = new ArrayList();

        while (tokenizer.hasMoreTokens()) {
            strings.add(tokenizer.nextToken());
        }

        Integer result = 0;
        for (String string : string) {
            result += Integer.parseInt(string);
        }

        return result;
    }
}