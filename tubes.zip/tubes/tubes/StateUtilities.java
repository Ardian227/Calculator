import java.util.ArrayList;
import java.util.List;

public class StateUtilities {

    private static List zeroToNine;

    private static List oneToNine;

    private static List operators;

    public static List getOneToNine() {
        if (oneToNine == null) {
            oneToNine = new ArrayList();
            oneToNine.add('1');
            oneToNine.add('2');
            oneToNine.add('3');
            oneToNine.add('4');
            oneToNine.add('5');
            oneToNine.add('6');
            oneToNine.add('7');
            oneToNine.add('8');
            oneToNine.add('9');
        }
        return oneToNine;
    }

    public static List getOperators() {
        if (operators == null) {
            operators = new ArrayList();
            operators.add('+');
        }
        return operators;
    }

    public static List getZeroToNine() {
        if (zeroToNine == null) {
            zeroToNine = new ArrayList();
            zeroToNine.add('0');
            zeroToNine.add('1');
            zeroToNine.add('2');
            zeroToNine.add('3');
            zeroToNine.add('4');
            zeroToNine.add('5');
            zeroToNine.add('6');
            zeroToNine.add('7');
            zeroToNine.add('8');
            zeroToNine.add('9');
        }
        return zeroToNine;
    }
}