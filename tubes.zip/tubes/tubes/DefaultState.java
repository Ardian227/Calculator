import java.util.LinkedList;
import java.util.List;

public class DefaultState implements State {

    private static final CharHelper[] CharHelper = null;

    private boolean startState;

    private boolean finalState;

    private List charHelpers = new LinkedList();

    public DefaultState(boolean startState, boolean finalState) {
        this.startState = startState;
        this.finalState = finalState;
    }

    public DefaultState(boolean startState, boolean finalState, List charHelpers) {
        this.startState = startState;
        this.finalState = finalState;
        this.charHelpers = charHelpers;
    }

    public void addCharHelper(CharHelper charHelper) {
        charHelpers.add(charHelper);
    }

    public boolean isStartState() {
        return startState;
    }

    public boolean isFinalState() {
        return finalState;
    }

    public State validateChar(Character c) throws Exception {
        for (CharHelper helper : CharHelper) {
            if (helper.acceptedCharacters().contains(c)) {
                return helper.getState();
            }
        }
        throw new Exception();
    }
}