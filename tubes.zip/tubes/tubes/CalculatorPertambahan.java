import javax.swing.JOptionPane;

public class CalculatorPertambahan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Buat State (Dalam Diagram Sebagai Lingkaran)
        DefaultState A = new DefaultState(true, false);
        DefaultState B = new DefaultState(true, true);
        DefaultState C = new DefaultState(true, false);

        // Buat helper (Dalam Diagram Sebagai Garis)
        CharHelper helper1 = new DefaultCharHelper(B, StateUtilities.getOneToNine());
        CharHelper helper2 = new DefaultCharHelper(B, StateUtilities.getZeroToNine());
        CharHelper helper3 = new DefaultCharHelper(C, StateUtilities.getOperators());
        CharHelper helper4 = new DefaultCharHelper(B, StateUtilities.getOneToNine());

        // masukan garis ke lingkaran
        A.addCharHelper(helper1);
        B.addCharHelper(helper2);
        B.addCharHelper(helper3);
        C.addCharHelper(helper4);

        // buat state manager
        StateManager manager = new StateManager(A);

        // masukkan input
        String input = JOptionPane.showInputDialog("Masukkan Input : ");
        if (input != null) {
            try {
                JOptionPane.showMessageDialog(null, manager.calculate(input));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "input yang dimasukkan tidak valid");
            }
        }
    }
}