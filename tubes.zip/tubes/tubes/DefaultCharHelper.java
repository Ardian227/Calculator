import java.util.List;

public class DefaultCharHelper implements CharHelper {

    private State state;

    private List acceptedCharacters;

    public DefaultCharHelper() {
    }

    public DefaultCharHelper(State state, List acceptedCharacters) {
        this.state = state;
        this.acceptedCharacters = acceptedCharacters;
    }

    public void setAcceptedCharacters(List acceptedCharacters) {
        this.acceptedCharacters = acceptedCharacters;
    }

    public void setState(State state) {
        this.state = state;
    }

    public List acceptedCharacters() {
        return acceptedCharacters;
    }

    public State getState() {
        return state;
    }
}