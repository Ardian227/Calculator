
public class JOptionPane {

    public static String showInputDialog(String string) {
        return null;
    }

    public static void showMessageDialog(Object object, String string) {
    }

    public static void showMessageDialog(Object object, Integer calculate) {
    }

}
